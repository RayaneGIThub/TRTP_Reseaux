# My Wonderful LINFO1341 Project

The very first thing you might want to do in this folder is the following command:
```bash
git init
```

This will initialize your Git repository.
You should also put it in a **private** repository (GitHub, GitLab, Bitbucket,... it is up to you but it **has to** stay private).

The Makefile contains all the required targets, but you might want to extend their behavior.

Very basic skelettons of receiver and sender source files are present, have a look to understand how you can enable logging or not.

A very simple test case is present, you probably want to update it.

You might be interested in the link simulator that can be found at https://github.com/cnp3/Linksimulator

And finally, if this message is still there at your final submission, it looks like you forgot to provide a proper README.